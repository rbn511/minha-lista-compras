package br.com.listacompras;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.SystemClock;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.function.Consumer;

/** Optional photos: only a barcode is sent; names and CSV prices stay on device. */
public final class ProductPhotos {
    public static final class Result {
        public final Bitmap bitmap;
        public final String source,page;
        Result(Bitmap b,String s,String p){bitmap=b;source=s;page=p;}
    }
    private final File directory;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final String[] catalogs={"openfoodfacts.org","openbeautyfacts.org"};
    private final long[] lastRequest={0,0};
    public ProductPhotos(Context context){directory=new File(context.getFilesDir(),"photos");directory.mkdirs();}
    private File file(String ean){return new File(directory,ean+".jpg");}
    public Bitmap cached(String ean){return ean.matches("[0-9]{8,14}")?BitmapFactory.decodeFile(file(ean).getAbsolutePath()):null;}
    public void load(String ean,Consumer<Result> callback){
        executor.execute(()->{
            if(!ean.matches("[0-9]{8,14}")){callback.accept(new Result(null,"",""));return;}
            Bitmap bitmap=cached(ean);
            File attribution=new File(directory,ean+".source");
            if(bitmap!=null&&attribution.isFile()){
                try(BufferedReader r=new BufferedReader(new FileReader(attribution))){String host=r.readLine();if("local".equals(host)){callback.accept(new Result(bitmap,"Foto no celular",""));return;}if(host.equals(catalogs[0])||host.equals(catalogs[1])){callback.accept(result(bitmap,host,ean));return;}}catch(Exception ignored){}
            }
            for(int i=0;i<catalogs.length;i++){
                if(Thread.currentThread().isInterrupted())return;
                try {
                    long wait=4100-(SystemClock.elapsedRealtime()-lastRequest[i]);
                    if(wait>0)Thread.sleep(wait);
                    lastRequest[i]=SystemClock.elapsedRealtime();
                    String host=catalogs[i];
                    byte[] json=download("https://world."+host+"/api/v2/product/"+ean+".json?fields=image_front_small_url",256*1024);
                    JSONObject product=new JSONObject(new String(json,StandardCharsets.UTF_8)).optJSONObject("product");
                    if(product==null)continue;
                    String url=product.optString("image_front_small_url","");
                    URL imageUrl=new URL(url);
                    if(!imageUrl.getProtocol().equals("https")||!(imageUrl.getHost().equals("images."+host)||imageUrl.getHost().equals("images.openfoodfacts.org")))continue;
                    byte[] bytes=download(url,2*1024*1024);
                    BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);
                    if(bounds.outWidth<=0||bounds.outHeight<=0||bounds.outWidth>4096||bounds.outHeight>4096)continue;
                    BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=Math.max(1,Math.max(bounds.outWidth,bounds.outHeight)/600);
                    bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);
                    if(bitmap==null)continue;
                    try(FileOutputStream stream=new FileOutputStream(file(ean))){bitmap.compress(Bitmap.CompressFormat.JPEG,85,stream);}
                    try(FileWriter writer=new FileWriter(attribution)){writer.write(host);}
                    callback.accept(result(bitmap,host,ean));return;
                }catch(InterruptedException ex){Thread.currentThread().interrupt();return;}catch(Exception ignored){}
            }
            callback.accept(new Result(null,"",""));
        });
    }
    private Result result(Bitmap bitmap,String host,String ean){return new Result(bitmap,host.equals(catalogs[0])?"Open Food Facts":"Open Beauty Facts","https://world."+host+"/product/"+ean);}
    private byte[] download(String address,int max) throws IOException {
        HttpURLConnection connection=(HttpURLConnection)new URL(address).openConnection();
        connection.setConnectTimeout(5000);connection.setReadTimeout(5000);connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("User-Agent","MinhaLista/1.1 (https://github.com/rbn511/minha-lista-compras)");
        try {
            if(connection.getResponseCode()!=200)throw new IOException("Imagem indisponível");
            try(InputStream input=connection.getInputStream();ByteArrayOutputStream output=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;
                while((n=input.read(buffer))!=-1){if(output.size()+n>max)throw new IOException("Resposta muito grande");output.write(buffer,0,n);}
                return output.toByteArray();
            }
        }finally{connection.disconnect();}
    }
    public void close(){executor.shutdownNow();}
    public void saveLocal(android.content.ContentResolver resolver,android.net.Uri uri,String ean)throws IOException{
        if(!ean.matches("[0-9]{8,14}"))throw new IOException("Código inválido");
        byte[] bytes;
        try(InputStream input=resolver.openInputStream(uri);ByteArrayOutputStream output=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int n;while((n=input.read(buffer))!=-1){if(output.size()+n>20*1024*1024)throw new IOException("Imagem muito grande");output.write(buffer,0,n);}bytes=output.toByteArray();
        }
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,bounds);if(bounds.outWidth<=0||bounds.outHeight<=0)throw new IOException("Imagem inválida");
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=Math.max(1,Math.max(bounds.outWidth,bounds.outHeight)/600);Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length,options);if(bitmap==null)throw new IOException("Imagem inválida");
        try(FileOutputStream output=new FileOutputStream(file(ean))){bitmap.compress(Bitmap.CompressFormat.JPEG,85,output);}finally{bitmap.recycle();}
        try(FileWriter writer=new FileWriter(new File(directory,ean+".source"))){writer.write("local");}
    }
}
