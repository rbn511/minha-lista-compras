package br.com.listacompras;

import com.journeyapps.barcodescanner.CaptureActivity;

public class PortraitScannerActivity extends CaptureActivity { }
