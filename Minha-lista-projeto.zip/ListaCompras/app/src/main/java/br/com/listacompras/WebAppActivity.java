package br.com.listacompras;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.webkit.WebViewAssetLoader;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** All application scripts are packaged assets; the bridge is never exposed to remote pages. */
public final class WebAppActivity extends ComponentActivity {
    private WebView web;
    private String pendingPhoto, pendingExport;
    private ProductPhotos photos;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ActivityResultLauncher<ScanOptions> scanner=registerForActivityResult(new ScanContract(),result->{if(result.getContents()!=null)send("scan","ean",result.getContents());});
    private final ActivityResultLauncher<String[]> csv=registerForActivityResult(new ActivityResultContracts.OpenDocument(),uri->readDocument(uri,"csv",16*1024*1024));
    private final ActivityResultLauncher<String[]> restore=registerForActivityResult(new ActivityResultContracts.OpenDocument(),uri->readDocument(uri,"restore",32*1024*1024));
    private final ActivityResultLauncher<String[]> gallery=registerForActivityResult(new ActivityResultContracts.OpenDocument(),uri->{
        final String ean=pendingPhoto;pendingPhoto=null;if(uri==null||ean==null)return;
        worker.execute(()->{try{photos.saveLocal(getContentResolver(),uri,ean);Bitmap image=photos.cached(ean);if(image==null)throw new IllegalArgumentException();ByteArrayOutputStream bytes=new ByteArrayOutputStream();image.compress(Bitmap.CompressFormat.JPEG,80,bytes);image.recycle();JSONObject message=new JSONObject();message.put("type","photo");message.put("ean",ean);message.put("url","data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));send(message);}catch(Exception e){send("error","message","Não foi possível abrir essa foto. Escolha uma imagem JPEG ou PNG.");}});
    });
    private final ActivityResultLauncher<String> exporter=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/json"),uri->{final String text=pendingExport;pendingExport=null;if(uri==null||text==null)return;worker.execute(()->{try(OutputStream stream=getContentResolver().openOutputStream(uri)){if(stream==null)throw new IllegalArgumentException();stream.write(text.getBytes(StandardCharsets.UTF_8));send("export","message","Cópia salva.");}catch(Exception e){send("error","message","Não foi possível salvar a cópia.");}});});
    @Override public void onCreate(Bundle state){super.onCreate(state);photos=new ProductPhotos(this);if(state!=null){pendingPhoto=state.getString("photo");pendingExport=state.getString("export");}
        web=new WebView(this);WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setJavaScriptCanOpenWindowsAutomatically(false);
        WebViewAssetLoader loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient(){@Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return loader.shouldInterceptRequest(request.getUrl());}@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){Uri u=request.getUrl();if(isTrusted(u))return false;if("https".equals(u.getScheme()))startActivity(new Intent(Intent.ACTION_VIEW,u));return true;}});
        web.addJavascriptInterface(new Bridge(),"AndroidCasa");setContentView(web);web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }
    static boolean isTrusted(Uri uri){return "https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost())&&uri.getPort()==-1&&uri.getPath()!=null&&uri.getPath().startsWith("/assets/");}
    private void send(String type,String key,String value){try{JSONObject message=new JSONObject();message.put("type",type);message.put(key,value);send(message);}catch(Exception ignored){}}
    private void send(JSONObject message){runOnUiThread(()->{if(!isDestroyed()&&web!=null&&isTrusted(Uri.parse(web.getUrl()==null?"":web.getUrl())))web.evaluateJavascript("window.CasaNativeResult("+message.toString()+")",null);});}
    private void readDocument(Uri uri,String type,int limit){if(uri==null)return;worker.execute(()->{try(InputStream stream=getContentResolver().openInputStream(uri)){if(stream==null)throw new IllegalArgumentException();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int count;while((count=stream.read(buffer))!=-1){if(out.size()+count>limit)throw new IllegalArgumentException();out.write(buffer,0,count);}send(type,"text",out.toString(StandardCharsets.UTF_8.name()));}catch(Exception e){send("error","message","Não foi possível abrir o arquivo. Confira o formato e o tamanho.");}});}
    public final class Bridge {
        @JavascriptInterface public String bootstrap(){try(ShoppingDatabase helper=new ShoppingDatabase(WebAppActivity.this)){return LegacyMigration.export(helper.getReadableDatabase(),photos).toString();}catch(Exception e){return "{\"error\":\"Não foi possível recuperar os dados da versão anterior. Feche e abra o aplicativo novamente.\"}";}}
        @JavascriptInterface public void scan(){runOnUiThread(()->scanner.launch(new ScanOptions().setCaptureActivity(PortraitScannerActivity.class).setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES).setPrompt("Aponte para o código com o celular em pé").setBeepEnabled(false).setOrientationLocked(true)));}
        @JavascriptInterface public void importCsv(){runOnUiThread(()->csv.launch(new String[]{"text/*","application/csv","application/octet-stream"}));}
        @JavascriptInterface public void restoreBackup(){runOnUiThread(()->restore.launch(new String[]{"application/json","text/*","application/octet-stream"}));}
        @JavascriptInterface public void choosePhoto(String ean){if(!ean.matches("[0-9]{8,14}"))return;runOnUiThread(()->{pendingPhoto=ean;gallery.launch(new String[]{"image/*"});});}
        @JavascriptInterface public void exportBackup(String text){if(text==null||text.length()>32*1024*1024)return;runOnUiThread(()->{pendingExport=text;exporter.launch("minha-casa-backup.json");});}
    }
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("photo",pendingPhoto);if(pendingExport!=null&&pendingExport.length()<100000)state.putString("export",pendingExport);}
    @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("AndroidCasa");web.destroy();}photos.close();worker.shutdown();super.onDestroy();}
}
