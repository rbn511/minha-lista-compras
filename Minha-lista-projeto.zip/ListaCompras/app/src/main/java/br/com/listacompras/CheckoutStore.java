package br.com.listacompras;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;

public final class CheckoutStore {
    public static void createTables(SQLiteDatabase db){
        db.execSQL("CREATE TABLE purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,finished_at INTEGER NOT NULL,total_cents INTEGER NOT NULL,units INTEGER NOT NULL,pantry_updated INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE purchase_items(purchase_id INTEGER NOT NULL,ean TEXT NOT NULL,name TEXT NOT NULL,cents INTEGER NOT NULL,qty INTEGER NOT NULL,PRIMARY KEY(purchase_id,ean))");
    }
    public static final class Receipt {
        public final long id,totalCents,units;
        Receipt(long id,long totalCents,long units){this.id=id;this.totalCents=totalCents;this.units=units;}
    }
    private static final class Item {
        final String ean,name;final long cents;final int qty;
        Item(Cursor c){ean=c.getString(0);name=c.getString(1);cents=c.getLong(2);qty=c.getInt(3);}
    }
    public static Receipt finish(SQLiteDatabase db,boolean updatePantry,long now){
        db.beginTransaction();
        try{
            ArrayList<Item> bought=new ArrayList<>();long total=0,units=0;
            try(Cursor c=db.rawQuery("SELECT ean,name,cents,qty FROM cart ORDER BY rowid",null)){
                while(c.moveToNext()){Item item=new Item(c);bought.add(item);total+=item.cents*item.qty;units+=item.qty;}
            }
            if(bought.isEmpty())throw new IllegalStateException("A lista está vazia. Esta compra já foi finalizada ou não tem itens.");
            if(updatePantry){
                for(Item item:bought){
                    int stock=PantryStore.quantity(db,item.ean);
                    if((long)stock+item.qty>PantryQuantity.MAX)throw new IllegalArgumentException("A despensa de "+item.name+" ultrapassaria 9999 unidades. Ajuste a quantidade antes de finalizar. Sua lista foi mantida.");
                }
            }
            ContentValues purchase=new ContentValues();purchase.put("finished_at",now);purchase.put("total_cents",total);purchase.put("units",units);purchase.put("pantry_updated",updatePantry?1:0);
            long id=db.insertOrThrow("purchases",null,purchase);
            for(Item item:bought){
                ContentValues detail=new ContentValues();detail.put("purchase_id",id);detail.put("ean",item.ean);detail.put("name",item.name);detail.put("cents",item.cents);detail.put("qty",item.qty);db.insertOrThrow("purchase_items",null,detail);
                if(updatePantry){
                    String pantryName=item.name;
                    try(Cursor c=db.rawQuery("SELECT name FROM pantry WHERE ean=?",new String[]{item.ean})){if(c.moveToFirst())pantryName=c.getString(0);}
                    PantryStore.save(db,item.ean,pantryName,PantryQuantity.changed(PantryStore.quantity(db,item.ean),item.qty));
                }
            }
            db.delete("cart",null,null);
            db.setTransactionSuccessful();return new Receipt(id,total,units);
        }finally{db.endTransaction();}
    }
}
