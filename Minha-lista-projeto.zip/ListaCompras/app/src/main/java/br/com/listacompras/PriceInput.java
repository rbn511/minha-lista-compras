package br.com.listacompras;

import java.math.BigDecimal;
public final class PriceInput {
    public static long cents(String input) {
        String value=input.trim();
        if(!value.matches("[0-9]+([,.][0-9]{1,2})?"))throw new IllegalArgumentException("Informe um preço como 19,90, sem símbolo de moeda.");
        long cents;
        try{cents=new BigDecimal(value.replace(',','.')).movePointRight(2).longValueExact();}
        catch(ArithmeticException ex){throw new IllegalArgumentException("Preço muito alto.");}
        if(cents>99999999)throw new IllegalArgumentException("Preço muito alto.");
        return cents;
    }
}
