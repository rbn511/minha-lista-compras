package br.com.listacompras;

import java.io.*;
import java.util.*;
import java.math.BigDecimal;

public final class CsvReader {
    public interface Sink { void product(String ean, String name, long cents) throws Exception; }
    public static List<String> row(PushbackReader reader) throws IOException {
        List<String> fields = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false, any = false;
        int ch;
        while ((ch = reader.read()) != -1) {
            any = true;
            if (ch == '"') {
                if (quoted) {
                    int next = reader.read();
                    if (next == '"') field.append('"');
                    else { quoted = false; if (next != -1) reader.unread(next); }
                } else quoted = true;
            } else if (ch == ';' && !quoted) { fields.add(field.toString()); field.setLength(0); }
            else if ((ch == '\n' || ch == '\r') && !quoted) {
                if (ch == '\r') { int next = reader.read(); if (next != '\n' && next != -1) reader.unread(next); }
                fields.add(field.toString()); return fields;
            } else field.append((char) ch);
        }
        if (quoted) throw new IOException("Aspas incompletas no CSV.");
        if (!any) return null;
        fields.add(field.toString()); return fields;
    }
    public static int read(Reader input, Sink sink) throws Exception {
        PushbackReader reader = new PushbackReader(input, 1);
        List<String> header = row(reader);
        if (header == null) throw new IOException("Arquivo vazio.");
        header.set(0, header.get(0).replace("\uFEFF", ""));
        int e = header.indexOf("EAN"), n = header.indexOf("Descricao"), p = header.indexOf("Preco");
        if (e < 0 || n < 0 || p < 0) throw new IOException("O CSV precisa das colunas EAN, Descricao e Preco, separadas por ponto e vírgula.");
        Set<String> seen = new HashSet<>();
        List<String> record; int line = 1;
        while ((record = row(reader)) != null) {
            line++;
            if (record.size() == 1 && record.get(0).trim().isEmpty()) continue;
            if (record.size() != header.size()) throw new IOException("Colunas incompletas no registro " + line);
            String ean = record.get(e).trim(), name = record.get(n).trim();
            if (!ean.matches("[0-9]{8,14}") || name.isEmpty()) throw new IOException("Produto inválido no registro " + line);
            if (seen.contains(ean)) continue;
            try {
                BigDecimal price = new BigDecimal(record.get(p).trim().replace(',', '.'));
                if (price.signum() < 0) throw new NumberFormatException();
                long cents = price.movePointRight(2).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact();
                sink.product(ean, name, cents); seen.add(ean);
            } catch (ArithmeticException | NumberFormatException ex) { throw new IOException("Preço inválido no registro " + line); }
        }
        if (seen.isEmpty()) throw new IOException("Nenhum produto encontrado.");
        return seen.size();
    }
}
