package br.com.listacompras;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public final class PantryStore {
    public static final String CREATE="CREATE TABLE pantry(ean TEXT PRIMARY KEY,name TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty BETWEEN 0 AND 9999))";
    public static int quantity(SQLiteDatabase db,String ean){
        try(Cursor c=db.rawQuery("SELECT qty FROM pantry WHERE ean=?",new String[]{ean})){return c.moveToFirst()?c.getInt(0):0;}
    }
    public static void save(SQLiteDatabase db,String ean,String name,int qty){
        if(qty<0||qty>PantryQuantity.MAX)throw new IllegalArgumentException("Quantidade inválida.");
        ContentValues values=new ContentValues();values.put("ean",ean);values.put("name",name);values.put("qty",qty);
        db.insertWithOnConflict("pantry",null,values,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public static void change(SQLiteDatabase db,String ean,int delta){
        db.beginTransaction();
        try{int qty=PantryQuantity.changed(quantity(db,ean),delta);ContentValues values=new ContentValues();values.put("qty",qty);db.update("pantry",values,"ean=?",new String[]{ean});db.setTransactionSuccessful();}finally{db.endTransaction();}
    }
}
