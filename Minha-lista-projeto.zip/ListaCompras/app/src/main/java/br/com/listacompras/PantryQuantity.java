package br.com.listacompras;

public final class PantryQuantity {
    public static final int MAX=9999;
    public static int parse(String input){
        String text=input.trim();
        if(!text.matches("[0-9]{1,4}"))throw new IllegalArgumentException("Informe uma quantidade inteira de 0 a 9999.");
        return Integer.parseInt(text);
    }
    public static int changed(int current,int delta){
        long next=(long)current+delta;
        if(next>MAX)throw new IllegalArgumentException("A quantidade máxima é 9999 unidades.");
        return (int)Math.max(0,next);
    }
    public static String notice(int quantity){
        if(quantity==0)return "Na despensa: nenhuma unidade";
        return "Você já tem "+quantity+(quantity==1?" unidade":" unidades")+" na despensa";
    }
}
