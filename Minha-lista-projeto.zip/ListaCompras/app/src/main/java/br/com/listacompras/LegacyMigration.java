package br.com.listacompras;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;

final class LegacyMigration {
 static JSONObject export(SQLiteDatabase db,ProductPhotos photos)throws Exception{
  JSONObject state=new JSONObject(),cart=new JSONObject(),pantry=new JSONObject(),catalog=new JSONObject(),images=new JSONObject();JSONArray history=new JSONArray();
  state.put("schema",2);state.put("listId","primeira-lista");state.put("cart",cart);state.put("pantry",pantry);state.put("metadata",new JSONObject());state.put("history",history);state.put("applied",new JSONArray());
  try(Cursor c=db.rawQuery("SELECT ean,name,cents FROM products",null)){while(c.moveToNext())catalog.put(c.getString(0),product(c.getString(0),c.getString(1),c.getLong(2)));}
  try(Cursor c=db.rawQuery("SELECT ean,name,cents,qty,checked FROM cart",null)){while(c.moveToNext()){JSONObject p=product(c.getString(0),c.getString(1),c.getLong(2));p.put("qty",c.getInt(3));p.put("checked",c.getInt(4)!=0);cart.put(c.getString(0),p);}}
  try(Cursor c=db.rawQuery("SELECT ean,name,qty FROM pantry",null)){while(c.moveToNext()){JSONObject p=new JSONObject();p.put("ean",c.getString(0));p.put("name",c.getString(1));p.put("qty",c.getInt(2));pantry.put(c.getString(0),p);}}
  try(Cursor c=db.rawQuery("SELECT id,finished_at,total_cents,pantry_updated FROM purchases ORDER BY finished_at DESC",null)){while(c.moveToNext()){JSONObject h=new JSONObject();h.put("id","anterior-"+c.getLong(0));h.put("date",c.getLong(1));h.put("total",c.getLong(2));h.put("pantryUpdated",c.getInt(3)!=0);JSONArray items=new JSONArray();try(Cursor detail=db.rawQuery("SELECT ean,name,cents,qty FROM purchase_items WHERE purchase_id=?",new String[]{c.getString(0)})){while(detail.moveToNext()){JSONObject p=product(detail.getString(0),detail.getString(1),detail.getLong(2));p.put("qty",detail.getInt(3));items.put(p);}}h.put("items",items);history.put(h);}}
  if(photos!=null){java.util.HashSet<String> codes=new java.util.HashSet<>();cart.keys().forEachRemaining(codes::add);pantry.keys().forEachRemaining(codes::add);for(String ean:codes){Bitmap b=photos.cached(ean);if(b==null)continue;ByteArrayOutputStream bytes=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.JPEG,80,bytes);b.recycle();JSONObject image=new JSONObject();image.put("url","data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP));image.put("credit","Foto salva na versão anterior");images.put(ean,image);}}
  JSONObject result=new JSONObject();result.put("state",state);result.put("catalog",catalog);result.put("photos",images);return result;
 }
 private static JSONObject product(String ean,String name,long cents)throws Exception{JSONObject p=new JSONObject();p.put("ean",ean);p.put("name",name);p.put("cents",cents);return p;}
}
