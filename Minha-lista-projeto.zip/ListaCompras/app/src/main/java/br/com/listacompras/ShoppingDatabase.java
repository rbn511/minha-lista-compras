package br.com.listacompras;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public final class ShoppingDatabase extends SQLiteOpenHelper {
    public ShoppingDatabase(Context context){super(context,"compras.db",null,4);}
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE products(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE cart(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL,qty INTEGER NOT NULL,checked INTEGER NOT NULL DEFAULT 0,manual_price INTEGER NOT NULL DEFAULT 0)");
        db.execSQL(PantryStore.CREATE);
        CheckoutStore.createTables(db);
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
        if(oldVersion<2)db.execSQL("ALTER TABLE cart ADD COLUMN manual_price INTEGER NOT NULL DEFAULT 0");
        if(oldVersion<3)db.execSQL(PantryStore.CREATE);
        if(oldVersion<4)CheckoutStore.createTables(db);
    }
}
