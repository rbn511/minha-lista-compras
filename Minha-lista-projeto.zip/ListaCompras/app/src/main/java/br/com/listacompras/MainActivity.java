package br.com.listacompras;

import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.journeyapps.barcodescanner.*;
import java.io.*;
import java.nio.charset.*;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.*;

public class MainActivity extends ComponentActivity {
    private SQLiteDatabase db;
    private LinearLayout root, items;
    private TextView base, total;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private volatile boolean importing;
    private ProductPhotos photos;
    private final ActivityResultLauncher<String[]> importer = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::importCsv);
    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(new ScanContract(), result -> {
        if (result.getContents() != null) findProduct(result.getContents());
    });
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        photos = new ProductPhotos(this);
        db = new SQLiteOpenHelper(this, "compras.db", null, 1) {
            public void onCreate(SQLiteDatabase d) {
                d.execSQL("CREATE TABLE products(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL)");
                d.execSQL("CREATE TABLE cart(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL,qty INTEGER NOT NULL,checked INTEGER NOT NULL DEFAULT 0)");
            }
            public void onUpgrade(SQLiteDatabase d,int a,int b) { }
        }.getWritableDatabase();
        db.enableWriteAheadLogging();
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(24),dp(20),dp(12)); root.setBackgroundColor(Color.rgb(245,247,242));
        setContentView(root);
        TextView title = label("Minha lista", 30); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        base = label("",14); root.addView(base);
        root.addView(button("Importar preços (.csv)", () -> { if (!importing) importer.launch(new String[]{"text/*","application/csv","application/octet-stream"}); }));
        root.addView(button("Escanear produto", () -> {
            if (!ready()) return;
            ScanOptions options = new ScanOptions().setCaptureActivity(PortraitScannerActivity.class).setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES).setPrompt("Aponte para o código de barras com o celular em pé").setBeepEnabled(false).setOrientationLocked(true);
            scanner.launch(options);
        }));
        root.addView(button("Buscar por nome ou código", this::search));
        total = label("",24); total.setTypeface(null,Typeface.BOLD); root.addView(total);
        ScrollView scroll = new ScrollView(this); items = new LinearLayout(this); items.setOrientation(1); scroll.addView(items);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(button("Limpar lista", () -> new android.app.AlertDialog.Builder(this).setTitle("Limpar lista?").setMessage("Todos os itens desta lista serão removidos.").setNegativeButton("Cancelar",null).setPositiveButton("Limpar",(d,w)->{db.delete("cart",null,null);refresh();}).show()));
        refresh();
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density); }
    private TextView label(String text,int size) { TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(Color.rgb(25,55,38));v.setPadding(0,dp(6),0,dp(6));return v; }
    private Button button(String text,Runnable action) { Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setOnClickListener(v->action.run());return b; }
    private void message(String text) { new android.app.AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show(); }
    private boolean ready() { if(importing){message("Aguarde a importação dos preços.");return false;}return true; }
    private void refresh() {
        try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM products",null)){c.moveToFirst();base.setText(importing?"Importando preços…":c.getInt(0)+" produtos disponíveis • preços salvos no celular");}
        items.removeAllViews(); long sum=0;int count=0;
        try(Cursor c=db.rawQuery("SELECT ean,name,cents,qty,checked FROM cart ORDER BY rowid DESC",null)) {
            while(c.moveToNext()) {
                String ean=c.getString(0),name=c.getString(1);long cents=c.getLong(2);int qty=c.getInt(3);boolean checked=c.getInt(4)==1;
                sum+=cents*qty;count+=qty;
                LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(8),dp(8),dp(8),dp(12));
                android.graphics.Bitmap cachedPhoto=photos.cached(ean);
                if(cachedPhoto!=null){ImageView thumbnail=new ImageView(this);thumbnail.setImageBitmap(cachedPhoto);thumbnail.setScaleType(ImageView.ScaleType.FIT_CENTER);thumbnail.setContentDescription("Foto de "+name);card.addView(thumbnail,new LinearLayout.LayoutParams(-1,dp(90)));}
                CheckBox check=new CheckBox(this);check.setText(name);check.setChecked(checked);check.setTextSize(16);
                check.setOnCheckedChangeListener((v,on)->{ContentValues values=new ContentValues();values.put("checked",on?1:0);db.update("cart",values,"ean=?",new String[]{ean});});card.addView(check);
                card.addView(label(qty+" × "+money.format(cents/100.0)+" = "+money.format(cents*qty/100.0),16));
                LinearLayout controls=new LinearLayout(this);
                controls.addView(button("−",()->change(ean,-1)));controls.addView(button("+",()->change(ean,1)));
                controls.addView(button("Remover",()->{db.delete("cart","ean=?",new String[]{ean});refresh();}));card.addView(controls);items.addView(card);
            }
        }
        total.setText("Total: "+money.format(sum/100.0));
        if(count==0)items.addView(label("Sua lista está vazia. Importe os preços e escaneie um produto para começar.",17));
    }
    private void change(String ean,int delta) {
        if(delta<0)db.execSQL("UPDATE cart SET qty=qty-1 WHERE ean=? AND qty>1",new Object[]{ean});
        else db.execSQL("UPDATE cart SET qty=qty+1 WHERE ean=? AND qty<9999",new Object[]{ean});
        refresh();
    }
    private void findProduct(String code) {
        if(!ready())return;
        try(Cursor c=db.rawQuery("SELECT name,cents FROM products WHERE ean=?",new String[]{code.trim()})) {
            if(!c.moveToFirst()){message("Código "+code+" não encontrado. Importe um CSV atualizado ou busque pelo nome.");return;}
            String name=c.getString(0);long cents=c.getLong(1);
            LinearLayout details=new LinearLayout(this);details.setOrientation(1);details.setPadding(dp(20),dp(8),dp(20),dp(8));
            details.addView(label(money.format(cents/100.0)+" por unidade",20));
            ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.FIT_CENTER);photo.setContentDescription("Foto de "+name);photo.setVisibility(View.GONE);details.addView(photo,new LinearLayout.LayoutParams(-1,dp(180)));
            TextView photoStatus=label("Buscando foto… Você já pode adicionar o produto.",13);details.addView(photoStatus);
            android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle(name).setView(details).setNegativeButton("Cancelar",null).setPositiveButton("Adicionar",(d,w)->add(code.trim(),name,cents)).create();
            dialog.show();
            photos.load(code.trim(),result->runOnUiThread(()->{
                if(isDestroyed()||!dialog.isShowing())return;
                if(result.bitmap!=null){photo.setImageBitmap(result.bitmap);photo.setVisibility(View.VISIBLE);photoStatus.setText("Foto: "+result.source+" • CC BY-SA • toque para ver a fonte");photoStatus.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(result.page))));}
                else photoStatus.setText("Foto indisponível. A lista e os preços continuam funcionando sem internet.");
            }));
        }
    }
    private void add(String ean,String name,long cents) {
        db.beginTransaction();
        try {
            ContentValues v=new ContentValues();v.put("ean",ean);v.put("name",name);v.put("cents",cents);v.put("qty",1);
            if(db.insertWithOnConflict("cart",null,v,SQLiteDatabase.CONFLICT_IGNORE)==-1) db.execSQL("UPDATE cart SET qty=MIN(qty+1,9999),checked=0 WHERE ean=?",new Object[]{ean});
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
        refresh();
    }
    private void search() {
        if(!ready())return;
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Nome ou código de barras");
        new android.app.AlertDialog.Builder(this).setTitle("Buscar produto").setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Buscar",(d,w)->{
            String query=input.getText().toString().trim();if(query.length()<2){message("Digite pelo menos dois caracteres.");return;}
            java.util.ArrayList<String> codes=new java.util.ArrayList<>(),names=new java.util.ArrayList<>();
            try(Cursor c=db.rawQuery("SELECT ean,name,cents FROM products WHERE ean=? OR name LIKE ? LIMIT 50",new String[]{query,"%"+query+"%"})) {
                while(c.moveToNext()){codes.add(c.getString(0));names.add(c.getString(1)+" • "+money.format(c.getLong(2)/100.0));}
            }
            if(codes.isEmpty()){message("Nenhum produto encontrado.");return;}
            new android.app.AlertDialog.Builder(this).setTitle("Resultados (até 50)").setItems(names.toArray(new String[0]),(dialog,pos)->findProduct(codes.get(pos))).setNegativeButton("Fechar",null).show();
        }).show();
    }
    private void importCsv(Uri uri) {
        if(uri==null||importing)return;
        importing=true; base.setText("Importando preços…");
        worker.execute(()->{
            String result;
            try {
                db.beginTransaction();
                try {
                    db.delete("products",null,null);
                    CharsetDecoder decoder=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
                    int count;
                    try(InputStream stream=getContentResolver().openInputStream(uri); Reader reader=new BufferedReader(new InputStreamReader(stream,decoder))) {
                        SQLiteStatement insert=db.compileStatement("INSERT INTO products(ean,name,cents) VALUES(?,?,?)");
                        try { count=CsvReader.read(reader,(ean,name,cents)->{insert.bindString(1,ean);insert.bindString(2,name);insert.bindLong(3,cents);insert.executeInsert();}); }
                        finally {insert.close();}
                    }
                    db.execSQL("UPDATE cart SET cents=(SELECT cents FROM products WHERE products.ean=cart.ean) WHERE ean IN (SELECT ean FROM products)");
                    db.setTransactionSuccessful();result=count+" produtos importados. Os preços dos itens da lista também foram atualizados.";
                } finally {db.endTransaction();}
            } catch(Exception ex) {result="Não foi possível importar. A base anterior foi mantida. Verifique se o arquivo está em UTF-8. "+ex.getMessage();}
            String output=result;runOnUiThread(()->{importing=false;if(!isDestroyed()){refresh();message(output);}});
        });
    }
    @Override protected void onDestroy(){photos.close();super.onDestroy();}
}
