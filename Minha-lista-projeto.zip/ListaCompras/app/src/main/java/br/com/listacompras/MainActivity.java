package br.com.listacompras;

import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.journeyapps.barcodescanner.*;
import java.io.*;
import java.nio.charset.*;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.*;

public class MainActivity extends ComponentActivity {
    private SQLiteDatabase db;
    private LinearLayout root, items;
    private TextView base, total;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private volatile boolean importing;
    private ProductPhotos photos;
    private String pendingPhotoEan;
    private boolean pantryMode, scannerForPantry, finishing;
    private int currentTab;
    private TextView title;
    private Button finishButton;
    private LinearLayout actionBar, summary;
    private ScrollView scroll;
    private final Button[] navButtons=new Button[4];
    private final int green=Color.rgb(22,107,76), ink=Color.rgb(25,55,38), muted=Color.rgb(102,119,109);
    private final ActivityResultLauncher<String[]> photoPicker=registerForActivityResult(new ActivityResultContracts.OpenDocument(),uri->{
        String ean=pendingPhotoEan;pendingPhotoEan=null;
        if(uri==null||ean==null)return;
        worker.execute(()->{String error=null;try{photos.saveLocal(getContentResolver(),uri,ean);}catch(Exception ex){error="Não foi possível abrir essa imagem. Escolha uma foto JPEG ou PNG.";}String result=error;runOnUiThread(()->{if(!isDestroyed()){if(result!=null)message(result);else refresh();}});});
    });
    private final ActivityResultLauncher<String[]> importer = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::importCsv);
    private final ActivityResultLauncher<ScanOptions> scanner = registerForActivityResult(new ScanContract(), result -> {
        if (result.getContents() != null) findProduct(result.getContents(), scannerForPantry);
    });
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        photos = new ProductPhotos(this);
        if(state!=null){pendingPhotoEan=state.getString("photoEan");currentTab=state.getInt("currentTab",0);scannerForPantry=state.getBoolean("scannerForPantry");}
        db = new ShoppingDatabase(this).getWritableDatabase();
        db.enableWriteAheadLogging();
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(16),dp(18),dp(8)); root.setBackgroundColor(Color.rgb(243,247,243));
        setContentView(root);
        TextView brand=label("MINHA CASA",11);brand.setLetterSpacing(.16f);brand.setTextColor(green);brand.setTypeface(null,Typeface.BOLD);root.addView(brand);
        title = label("Compras", 28); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        base = label("",13);base.setTextColor(muted);root.addView(base);
        actionBar=new LinearLayout(this);addWeighted(actionBar,primaryButton("Escanear",this::startScanner));addWeighted(actionBar,button("Buscar",this::search));root.addView(actionBar);
        summary=card();summary.setPadding(dp(16),dp(10),dp(16),dp(10));summary.setBackground(rounded(Color.rgb(222,239,227),0));
        total = label("",24); total.setTypeface(null,Typeface.BOLD);summary.addView(total);root.addView(summary);
        scroll = new ScrollView(this);scroll.setClipToPadding(false);scroll.setPadding(0,dp(10),0,dp(6));items = new LinearLayout(this); items.setOrientation(1); scroll.addView(items);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        finishButton=primaryButton("Finalizar compra",this::finishPurchase);LinearLayout.LayoutParams finishLayout=new LinearLayout.LayoutParams(-1,-2);finishLayout.setMargins(0,dp(6),0,dp(8));root.addView(finishButton,finishLayout);
        LinearLayout navigation=new LinearLayout(this);navigation.setPadding(0,dp(8),0,0);
        String[] labels={"Compras","Despensa","Histórico","Mais"};int[] icons={R.drawable.ic_cart,R.drawable.ic_pantry,R.drawable.ic_history,R.drawable.ic_menu};
        for(int i=0;i<labels.length;i++){final int page=i;Button tab=button(labels[i],()->switchTab(page));tab.setTextSize(11);tab.setPadding(dp(2),dp(7),dp(2),dp(7));tab.setContentDescription("Abrir "+labels[i]);android.graphics.drawable.Drawable icon=getDrawable(icons[i]);icon.setBounds(0,0,dp(23),dp(23));tab.setCompoundDrawables(null,icon,null,null);tab.setCompoundDrawablePadding(dp(5));navButtons[i]=tab;addWeighted(navigation,tab);}
        root.addView(navigation);
        refresh();
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density); }
    private TextView label(String text,int size) { TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(Color.rgb(25,55,38));v.setPadding(0,dp(6),0,dp(6));return v; }
    private GradientDrawable rounded(int fill,int stroke){GradientDrawable shape=new GradientDrawable();shape.setColor(fill);shape.setCornerRadius(dp(15));if(stroke!=0)shape.setStroke(dp(1),stroke);return shape;}
    private void styleButton(Button b,boolean primary){int fill=primary?green:Color.WHITE;b.setTextColor(primary?Color.WHITE:green);b.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(181,211,193)),rounded(fill,primary?0:Color.rgb(218,228,219)),null));b.setMinHeight(dp(48));b.setMinimumWidth(0);b.setPadding(dp(10),dp(9),dp(10),dp(9));b.setTextSize(14);}
    private Button button(String text,Runnable action) { Button b=new Button(this);b.setText(text);b.setAllCaps(false);styleButton(b,false);b.setOnClickListener(v->action.run());return b; }
    private Button primaryButton(String text,Runnable action){Button b=button(text,action);styleButton(b,true);return b;}
    private void addWeighted(LinearLayout row,View view){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),dp(5),dp(3),dp(5));row.addView(view,p);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(1);c.setPadding(dp(14),dp(12),dp(14),dp(14));c.setBackground(rounded(Color.WHITE,Color.rgb(226,233,226)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));c.setLayoutParams(p);return c;}
    private void switchTab(int page){currentTab=page;scroll.scrollTo(0,0);refresh();}
    private void startScanner(){if(!ready())return;scannerForPantry=pantryMode;ScanOptions options=new ScanOptions().setCaptureActivity(PortraitScannerActivity.class).setDesiredBarcodeFormats(ScanOptions.ONE_D_CODE_TYPES).setPrompt("Aponte para o código de barras com o celular em pé").setBeepEnabled(false).setOrientationLocked(true);scanner.launch(options);}
    private void message(String text) { new android.app.AlertDialog.Builder(this).setMessage(text).setPositiveButton("OK",null).show(); }
    private boolean ready() { if(importing){message("Aguarde a importação dos preços.");return false;}return true; }
    private void refresh() {
        pantryMode=currentTab==1;String[] titles={"Minhas compras","Minha despensa","Histórico","Mais opções"};title.setText(titles[currentTab]);
        for(int i=0;i<navButtons.length;i++){Button nav=navButtons[i];nav.setTextColor(i==currentTab?green:muted);nav.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.rgb(181,211,193)),rounded(i==currentTab?Color.rgb(222,239,227):Color.TRANSPARENT,0),null));nav.getCompoundDrawables()[1].setTint(i==currentTab?green:muted);}
        actionBar.setVisibility(currentTab<2?View.VISIBLE:View.GONE);summary.setVisibility(currentTab<2?View.VISIBLE:View.GONE);finishButton.setVisibility(currentTab==0?View.VISIBLE:View.GONE);
        base.setText(importing?"Importando preços…":currentTab==0?"Planeje suas compras e veja o que já tem em casa.":currentTab==1?"Seu estoque em casa, sempre à mão.":currentTab==2?"Consulte suas compras finalizadas.":"Preços, organização e ajuda.");
        if(currentTab==2){refreshHistory();return;}if(currentTab==3){refreshOptions();return;}
        if(pantryMode){refreshPantry();return;}
        items.removeAllViews(); long sum=0;int count=0;
        try(Cursor c=db.rawQuery("SELECT cart.ean,cart.name,cents,cart.qty,checked,COALESCE(pantry.qty,0) FROM cart LEFT JOIN pantry ON pantry.ean=cart.ean ORDER BY cart.rowid DESC",null)) {
            while(c.moveToNext()) {
                String ean=c.getString(0),name=c.getString(1);long cents=c.getLong(2);int qty=c.getInt(3);boolean checked=c.getInt(4)==1;
                sum+=cents*qty;count+=qty;
                LinearLayout card=card();
                android.graphics.Bitmap cachedPhoto=photos.cached(ean);
                if(cachedPhoto!=null){ImageView thumbnail=new ImageView(this);thumbnail.setImageBitmap(cachedPhoto);thumbnail.setScaleType(ImageView.ScaleType.FIT_CENTER);thumbnail.setContentDescription("Foto de "+name);card.addView(thumbnail,new LinearLayout.LayoutParams(-1,dp(90)));}
                CheckBox check=new CheckBox(this);check.setText(name);check.setChecked(checked);check.setTextSize(16);
                check.setOnCheckedChangeListener((v,on)->{ContentValues values=new ContentValues();values.put("checked",on?1:0);db.update("cart",values,"ean=?",new String[]{ean});});card.addView(check);
                card.addView(label(qty+" × "+money.format(cents/100.0)+" = "+money.format(cents*qty/100.0),16));
                card.addView(label(PantryQuantity.notice(c.getInt(5)),14));
                LinearLayout controls=new LinearLayout(this);
                addWeighted(controls,button("−",()->change(ean,-1)));addWeighted(controls,button("+",()->change(ean,1)));
                addWeighted(controls,button("Remover",()->{db.delete("cart","ean=?",new String[]{ean});refresh();}));card.addView(controls);items.addView(card);
                LinearLayout extra=new LinearLayout(this);
                addWeighted(extra,button("Alterar preço",()->editPrice(ean,name,cents)));
                addWeighted(extra,button("Adicionar foto",()->{pendingPhotoEan=ean;photoPicker.launch(new String[]{"image/*"});}));card.addView(extra);
            }
        }
        total.setText("Total: "+money.format(sum/100.0));
        finishButton.setEnabled(count>0&&!importing);finishButton.setAlpha(count>0&&!importing?1f:.45f);
        if(count==0){LinearLayout empty=card();empty.addView(label("Vamos montar sua lista?",21));empty.addView(label("Escaneie um produto ou use a busca. Para importar seu CSV, abra a aba Mais.",16));items.addView(empty);}
        else items.addView(label(count+" unidades na lista • finalizar considera todos os itens.",13));
    }
    private void change(String ean,int delta) {
        if(delta<0)db.execSQL("UPDATE cart SET qty=qty-1 WHERE ean=? AND qty>1",new Object[]{ean});
        else db.execSQL("UPDATE cart SET qty=qty+1 WHERE ean=? AND qty<9999",new Object[]{ean});
        refresh();
        if(delta>0){int stock=PantryStore.quantity(db,ean);if(stock>0)Toast.makeText(this,PantryQuantity.notice(stock),Toast.LENGTH_LONG).show();}
    }
    private void findProduct(String code,boolean forPantry) {
        if(!ready())return;
        code=code.trim();
        if(!code.matches("[0-9]{8,14}")){message("Código de barras inválido.");return;}
        if(forPantry){String name="";try(Cursor c=db.rawQuery("SELECT name FROM products WHERE ean=? UNION ALL SELECT name FROM pantry WHERE ean=? UNION ALL SELECT name FROM cart WHERE ean=? LIMIT 1",new String[]{code,code,code})){if(c.moveToFirst())name=c.getString(0);}pantryDialog(code,name);return;}
        try(Cursor c=db.rawQuery("SELECT name,cents FROM products WHERE ean=?",new String[]{code.trim()})) {
            if(!c.moveToFirst()){try(Cursor existing=db.rawQuery("SELECT name,cents FROM cart WHERE ean=?",new String[]{code})){if(existing.moveToFirst()){productDialog(code,existing.getString(0),existing.getLong(1),true,false);return;}}try(Cursor stored=db.rawQuery("SELECT name FROM pantry WHERE ean=?",new String[]{code})){if(stored.moveToFirst()){productDialog(code,stored.getString(0),0,true,false);return;}}productDialog(code,"",0,true,true);return;}
            String name=c.getString(0);long cents=c.getLong(1);boolean manual=false;
            try(Cursor cart=db.rawQuery("SELECT cents,manual_price FROM cart WHERE ean=?",new String[]{code})){if(cart.moveToFirst()&&cart.getInt(1)==1){cents=cart.getLong(0);manual=true;}}
            productDialog(code,name,cents,manual,false);
        }
    }
    private EditText priceField(long cents){EditText field=new EditText(this);field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);field.setSingleLine(true);field.setSelectAllOnFocus(true);field.setHint("Preço unitário (R$)");field.setText(String.format(new Locale("pt","BR"),"%.2f",cents/100.0));return field;}
    private void editPrice(String ean,String name,long cents){
        if(!ready())return;
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),dp(8),dp(20),dp(8));box.addView(label("Preço unitário (R$)",16));EditText input=priceField(cents);box.addView(input);box.addView(label("O preço fica salvo nesta lista e será mantido ao importar outro CSV.",13));
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle(name).setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",null).create();dialog.show();dialog.getButton(-1).setOnClickListener(v->{
            if(!ready())return;
            try{long value=PriceInput.cents(input.getText().toString());ContentValues values=new ContentValues();values.put("cents",value);values.put("manual_price",1);db.update("cart",values,"ean=?",new String[]{ean});dialog.dismiss();refresh();}catch(IllegalArgumentException ex){input.setError(ex.getMessage());}
        });
    }
    private void productDialog(String code,String name,long cents,boolean wasManual,boolean unknown){
            LinearLayout details=new LinearLayout(this);details.setOrientation(1);details.setPadding(dp(20),dp(8),dp(20),dp(8));
            EditText nameField=new EditText(this);nameField.setHint("Nome do produto");if(unknown){details.addView(label("Produto fora do CSV. Informe nome e preço.",14));details.addView(nameField);}
            TextView stockNotice=label(PantryQuantity.notice(PantryStore.quantity(db,code)),18);stockNotice.setTypeface(null,Typeface.BOLD);details.addView(stockNotice);
            details.addView(label("Preço unitário (R$)",16));EditText price=priceField(cents);details.addView(price);
            ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.FIT_CENTER);photo.setContentDescription("Foto de "+name);photo.setVisibility(View.GONE);details.addView(photo,new LinearLayout.LayoutParams(-1,dp(180)));
            TextView photoStatus=label("Buscando foto… Você já pode adicionar o produto.",13);details.addView(photoStatus);
            ScrollView scroll=new ScrollView(this);scroll.addView(details);
            android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle(unknown?"Adicionar produto":name).setView(scroll).setNegativeButton("Cancelar",null).setPositiveButton("Adicionar",null).create();
            dialog.show();
            dialog.getButton(-1).setOnClickListener(v->{if(!ready())return;String chosenName=unknown?nameField.getText().toString().trim():name;if(chosenName.isEmpty()){nameField.setError("Informe o nome do produto.");return;}try{long chosenPrice=PriceInput.cents(price.getText().toString());add(code,chosenName,chosenPrice,wasManual||unknown||chosenPrice!=cents);dialog.dismiss();}catch(IllegalArgumentException ex){price.setError(ex.getMessage());}});
            photos.load(code.trim(),result->runOnUiThread(()->{
                if(isDestroyed())return;
                refresh();if(!dialog.isShowing())return;
                if(result.bitmap!=null){photo.setImageBitmap(result.bitmap);photo.setVisibility(View.VISIBLE);photoStatus.setText(result.page.isEmpty()?"Foto adicionada no celular":"Foto: "+result.source+" • CC BY-SA • toque para ver a fonte");if(!result.page.isEmpty())photoStatus.setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(result.page))));}
                else photoStatus.setText("Foto indisponível. A lista e os preços continuam funcionando sem internet.");
            }));
    }
    private void add(String ean,String name,long cents,boolean manual) {
        db.beginTransaction();
        try {
            ContentValues v=new ContentValues();v.put("ean",ean);v.put("name",name);v.put("cents",cents);v.put("qty",1);v.put("manual_price",manual?1:0);
            if(db.insertWithOnConflict("cart",null,v,SQLiteDatabase.CONFLICT_IGNORE)==-1) db.execSQL("UPDATE cart SET qty=MIN(qty+1,9999),checked=0,cents=?,manual_price=? WHERE ean=?",new Object[]{cents,manual?1:0,ean});
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
        currentTab=0;refresh();
    }
    private void search() {
        if(!ready())return;
        boolean forPantry=pantryMode;
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Nome ou código de barras");
        new android.app.AlertDialog.Builder(this).setTitle("Buscar produto").setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Buscar",(d,w)->{
            String query=input.getText().toString().trim();if(query.length()<2){message("Digite pelo menos dois caracteres.");return;}
            java.util.ArrayList<String> codes=new java.util.ArrayList<>(),names=new java.util.ArrayList<>();
            if(query.matches("[0-9]{8,14}")){findProduct(query,forPantry);return;}
            try(Cursor c=db.rawQuery("SELECT ean,name,cents FROM (SELECT ean,name,cents FROM products UNION ALL SELECT ean,name,0 FROM pantry WHERE ean NOT IN (SELECT ean FROM products) UNION ALL SELECT ean,name,cents FROM cart WHERE ean NOT IN (SELECT ean FROM products) AND ean NOT IN (SELECT ean FROM pantry)) WHERE name LIKE ? LIMIT 50",new String[]{"%"+query+"%"})) {
                while(c.moveToNext()){String ean=c.getString(0);codes.add(ean);names.add(c.getString(1)+" • "+PantryQuantity.notice(PantryStore.quantity(db,ean)));}
            }
            if(codes.isEmpty()){message("Nenhum produto encontrado.");return;}
            new android.app.AlertDialog.Builder(this).setTitle("Resultados (até 50)").setItems(names.toArray(new String[0]),(dialog,pos)->findProduct(codes.get(pos),forPantry)).setNegativeButton("Fechar",null).show();
        }).show();
    }
    private void importCsv(Uri uri) {
        if(uri==null||importing)return;
        importing=true; base.setText("Importando preços…");
        worker.execute(()->{
            String result;
            try {
                db.beginTransaction();
                try {
                    db.delete("products",null,null);
                    CharsetDecoder decoder=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
                    int count;
                    try(InputStream stream=getContentResolver().openInputStream(uri); Reader reader=new BufferedReader(new InputStreamReader(stream,decoder))) {
                        SQLiteStatement insert=db.compileStatement("INSERT INTO products(ean,name,cents) VALUES(?,?,?)");
                        try { count=CsvReader.read(reader,(ean,name,cents)->{insert.bindString(1,ean);insert.bindString(2,name);insert.bindLong(3,cents);insert.executeInsert();}); }
                        finally {insert.close();}
                    }
                    db.execSQL("UPDATE cart SET cents=(SELECT cents FROM products WHERE products.ean=cart.ean) WHERE manual_price=0 AND ean IN (SELECT ean FROM products)");
                    db.setTransactionSuccessful();result=count+" produtos importados. Os preços da lista foram atualizados, mantendo os preços informados manualmente.";
                } finally {db.endTransaction();}
            } catch(Exception ex) {result="Não foi possível importar. A base anterior foi mantida. Verifique se o arquivo está em UTF-8. "+ex.getMessage();}
            String output=result;runOnUiThread(()->{importing=false;if(!isDestroyed()){refresh();message(output);}});
        });
    }
    private void refreshPantry(){
        items.removeAllViews();long units=0;int kinds=0;
        try(Cursor c=db.rawQuery("SELECT ean,name,qty FROM pantry ORDER BY name COLLATE NOCASE",null)){
            while(c.moveToNext()){String ean=c.getString(0),name=c.getString(1);int qty=c.getInt(2);units+=qty;kinds++;
                LinearLayout card=card();TextView productName=label(name,18);productName.setTypeface(null,Typeface.BOLD);card.addView(productName);card.addView(label(PantryQuantity.notice(qty),16));
                LinearLayout controls=new LinearLayout(this);addWeighted(controls,button("Consumir 1",()->changePantry(ean,-1)));addWeighted(controls,button("Entrou 1",()->changePantry(ean,1)));card.addView(controls);
                LinearLayout actions=new LinearLayout(this);addWeighted(actions,button("Editar estoque",()->pantryDialog(ean,name)));addWeighted(actions,button("Comprar",()->findProduct(ean,false)));card.addView(actions);items.addView(card);
            }
        }
        total.setText(kinds+" produtos • "+units+" unidades");
        if(kinds==0)items.addView(label("Cadastre o que você tem em casa: escaneie o produto ou busque pelo nome/código e informe a quantidade.",17));
        items.addView(label("Registre o consumo e as entradas. Ao finalizar uma compra, você pode atualizar a despensa.",14));
    }
    private void finishPurchase(){
        if(!ready()||finishing)return;
        long units=0,sum=0;
        try(Cursor c=db.rawQuery("SELECT qty,cents FROM cart",null)){while(c.moveToNext()){units+=c.getInt(0);sum+=c.getLong(1)*c.getInt(0);}}
        if(units==0){message("Adicione produtos antes de finalizar a compra.");return;}
        String text="Você está finalizando "+units+" unidades, no total de "+money.format(sum/100.0)+".\n\nTodos os itens da lista serão considerados comprados, inclusive os não marcados.\n\nDeseja somar essas quantidades à despensa? A compra ficará no Histórico e a lista será esvaziada.";
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle("Finalizar compra").setMessage(text).setPositiveButton("Sim, atualizar",null).setNegativeButton("Não, só finalizar",null).setNeutralButton("Cancelar",null).create();dialog.show();
        dialog.getButton(-1).setOnClickListener(v->completePurchase(dialog,true));dialog.getButton(-2).setOnClickListener(v->completePurchase(dialog,false));
    }
    private void completePurchase(android.app.AlertDialog dialog,boolean updatePantry){
        if(!ready()||finishing)return;finishing=true;
        try{CheckoutStore.Receipt receipt=CheckoutStore.finish(db,updatePantry,System.currentTimeMillis());dialog.dismiss();refresh();message("Compra finalizada: "+money.format(receipt.totalCents/100.0)+".\n\n"+(updatePantry?"As quantidades foram somadas à despensa.":"O estoque da despensa foi mantido.")+"\n\nVocê pode consultar os itens na aba Histórico.");}
        catch(IllegalArgumentException|IllegalStateException ex){dialog.dismiss();message(ex.getMessage());}
        catch(android.database.SQLException ex){dialog.dismiss();message("Não foi possível finalizar a compra. A lista e a despensa foram mantidas. Tente novamente.");}
        finally{finishing=false;}
    }
    private String purchaseDate(long timestamp){return new java.text.SimpleDateFormat("dd/MM/yyyy 'às' HH:mm",new Locale("pt","BR")).format(new java.util.Date(timestamp));}
    private void refreshHistory(){
        items.removeAllViews();int count=0;
        try(Cursor c=db.rawQuery("SELECT id,finished_at,total_cents,units,pantry_updated FROM purchases ORDER BY id DESC LIMIT 50",null)){
            while(c.moveToNext()){long id=c.getLong(0),date=c.getLong(1),cents=c.getLong(2),units=c.getLong(3);boolean updated=c.getInt(4)==1;count++;
                LinearLayout entry=card();TextView amount=label(money.format(cents/100.0),24);amount.setTypeface(null,Typeface.BOLD);entry.addView(amount);entry.addView(label(purchaseDate(date),15));entry.addView(label(units+" unidades • "+(updated?"Despensa atualizada":"Despensa mantida"),13));entry.addView(button("Ver produtos",()->purchaseDetails(id,date)));items.addView(entry);
            }
        }
        if(count==0){LinearLayout empty=card();empty.addView(label("Suas compras ficam aqui",21));empty.addView(label("Ao finalizar uma compra, os produtos, preços e quantidades serão salvos neste histórico.",16));items.addView(empty);}
        else items.addView(label("Exibindo as 50 compras mais recentes.",13));
    }
    private void purchaseDetails(long id,long date){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(18),dp(8),dp(18),dp(8));long sum=0;
        try(Cursor c=db.rawQuery("SELECT name,cents,qty FROM purchase_items WHERE purchase_id=? ORDER BY name",new String[]{Long.toString(id)})){
            while(c.moveToNext()){long cents=c.getLong(1);int qty=c.getInt(2);sum+=cents*qty;box.addView(label(c.getString(0),17));box.addView(label(qty+" × "+money.format(cents/100.0)+" = "+money.format(cents*qty/100.0),14));}
        }
        TextView sumLabel=label("Total: "+money.format(sum/100.0),21);sumLabel.setTypeface(null,Typeface.BOLD);box.addView(sumLabel);ScrollView details=new ScrollView(this);details.addView(box);new android.app.AlertDialog.Builder(this).setTitle(purchaseDate(date)).setView(details).setPositiveButton("Fechar",null).show();
    }
    private void refreshOptions(){
        items.removeAllViews();int products=0;try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM products",null)){c.moveToFirst();products=c.getInt(0);}
        LinearLayout prices=card();prices.addView(label("Seus preços",21));prices.addView(label(products+" produtos disponíveis no celular",14));prices.addView(label("Atualize os preços escolhendo seu arquivo CSV.",14));prices.addView(primaryButton("Importar preços (.csv)",()->{if(ready())importer.launch(new String[]{"text/*","application/csv","application/octet-stream"});}));items.addView(prices);
        LinearLayout organize=card();organize.addView(label("Organizar a lista",21));organize.addView(label("Esvaziar a lista não registra uma compra nem altera o estoque em casa.",14));organize.addView(button("Limpar lista de compras",()->{
            if(!ready())return;new android.app.AlertDialog.Builder(this).setTitle("Limpar lista?").setMessage("Os itens da lista serão removidos. A despensa e o Histórico serão mantidos.").setNegativeButton("Cancelar",null).setPositiveButton("Limpar",(d,w)->{if(ready()){db.delete("cart",null,null);refresh();}}).show();
        }));items.addView(organize);
        LinearLayout help=card();help.addView(label("Como usar",21));help.addView(label("Compras: escaneie ou busque produtos, informe o preço e ajuste a quantidade. As marcações servem para conferir os itens; finalizar considera a lista inteira.",15));help.addView(label("Despensa: cadastre o que tem em casa e registre o consumo. A quantidade disponível aparece quando você vai comprar.",15));help.addView(label("Finalizar compra: escolha se deseja somar as unidades compradas à despensa. O histórico guarda o registro da compra.",15));help.addView(label("Fotos: se a imagem não estiver disponível, escolha uma foto do celular no item da lista.",15));items.addView(help);
        items.addView(label("Minha lista • versão 1.4\nLista, despensa e histórico salvos neste celular.",13));
    }
    private void changePantry(String ean,int delta){try{PantryStore.change(db,ean,delta);refresh();}catch(IllegalArgumentException ex){message(ex.getMessage());}}
    private void pantryDialog(String ean,String name){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),dp(8),dp(20),dp(8));
        box.addView(label("Nome do produto",16));EditText nameField=new EditText(this);nameField.setSingleLine(true);nameField.setText(name);box.addView(nameField);
        box.addView(label("Quantidade total que você tem em casa",16));EditText quantity=new EditText(this);quantity.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);quantity.setSingleLine(true);quantity.setSelectAllOnFocus(true);quantity.setText(Integer.toString(PantryStore.quantity(db,ean)));box.addView(quantity);box.addView(label("Informe unidades inteiras. Salvar substitui a quantidade atual; use 0 quando acabar.",14));
        android.app.AlertDialog dialog=new android.app.AlertDialog.Builder(this).setTitle("Cadastrar na despensa").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",null).create();dialog.show();dialog.getButton(-1).setOnClickListener(v->{if(!ready())return;String chosenName=nameField.getText().toString().trim();if(chosenName.isEmpty()){nameField.setError("Informe o nome do produto.");return;}try{int qty=PantryQuantity.parse(quantity.getText().toString());PantryStore.save(db,ean,chosenName,qty);dialog.dismiss();refresh();}catch(IllegalArgumentException ex){quantity.setError(ex.getMessage());}});
    }
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("photoEan",pendingPhotoEan);state.putInt("currentTab",currentTab);state.putBoolean("scannerForPantry",scannerForPantry);}
    @Override protected void onDestroy(){photos.close();worker.shutdown();super.onDestroy();}
}
