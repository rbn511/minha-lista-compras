package br.com.listacompras;
import org.junit.Test;
import static org.junit.Assert.*;
public class PriceInputTest {
    @Test public void acceptsDecimalCommaAndDot(){assertEquals(1990,PriceInput.cents("19,90"));assertEquals(1990,PriceInput.cents("19.90"));assertEquals(0,PriceInput.cents("0"));assertEquals(450,PriceInput.cents("4,5"));assertEquals(1000,PriceInput.cents(" 10 "));}
    @Test(expected=IllegalArgumentException.class) public void rejectsNegative(){PriceInput.cents("-2,50");}
    @Test(expected=IllegalArgumentException.class) public void rejectsEmpty(){PriceInput.cents("");}
    @Test(expected=IllegalArgumentException.class) public void rejectsAmbiguousSeparators(){PriceInput.cents("1.234,56");}
    @Test(expected=IllegalArgumentException.class) public void rejectsExtraDecimals(){PriceInput.cents("1,234");}
    @Test(expected=IllegalArgumentException.class) public void rejectsHugeValue(){PriceInput.cents("9999999999999999999999999999");}
}
