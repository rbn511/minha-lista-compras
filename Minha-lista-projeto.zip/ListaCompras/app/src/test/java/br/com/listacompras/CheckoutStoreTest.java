package br.com.listacompras;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class CheckoutStoreTest {
    private Context context;private ShoppingDatabase helper;private SQLiteDatabase db;
    @Before public void setup(){context=RuntimeEnvironment.getApplication();context.deleteDatabase("compras.db");helper=new ShoppingDatabase(context);db=helper.getWritableDatabase();}
    @After public void cleanup(){helper.close();context.deleteDatabase("compras.db");}
    private void cart(String ean,String name,int cents,int qty,int checked){db.execSQL("INSERT INTO cart(ean,name,cents,qty,checked) VALUES(?,?,?,?,?)",new Object[]{ean,name,cents,qty,checked});}
    private long scalar(String sql){try(Cursor c=db.rawQuery(sql,null)){assertTrue(c.moveToFirst());return c.getLong(0);}}
    @Test public void finalizesAllItemsAndAddsToExistingStock(){
        cart("00000001","Arroz",500,2,1);cart("00000002","Feijão",800,3,0);PantryStore.save(db,"00000001","Arroz da casa",4);PantryStore.save(db,"00000003","Café",1);
        CheckoutStore.Receipt receipt=CheckoutStore.finish(db,true,123456L);
        assertEquals(3400,receipt.totalCents);assertEquals(5,receipt.units);assertEquals(6,PantryStore.quantity(db,"00000001"));assertEquals(3,PantryStore.quantity(db,"00000002"));assertEquals(1,PantryStore.quantity(db,"00000003"));assertEquals(0,scalar("SELECT COUNT(*) FROM cart"));assertEquals(2,scalar("SELECT COUNT(*) FROM purchase_items"));assertEquals(1,scalar("SELECT pantry_updated FROM purchases"));assertEquals(123456L,scalar("SELECT finished_at FROM purchases"));
        try(Cursor c=db.rawQuery("SELECT name FROM pantry WHERE ean='00000001'",null)){c.moveToFirst();assertEquals("Arroz da casa",c.getString(0));}
    }
    @Test public void canFinalizeWithoutUpdatingPantry(){
        cart("00000001","Arroz",500,2,0);cart("00000002","Feijão",800,3,0);PantryStore.save(db,"00000001","Arroz",4);
        CheckoutStore.finish(db,false,10L);
        assertEquals(4,PantryStore.quantity(db,"00000001"));assertEquals(0,PantryStore.quantity(db,"00000002"));assertEquals(1,scalar("SELECT COUNT(*) FROM pantry"));assertEquals(0,scalar("SELECT COUNT(*) FROM cart"));assertEquals(0,scalar("SELECT pantry_updated FROM purchases"));
    }
    @Test public void retryCannotDuplicateStockOrHistory(){
        cart("00000001","Arroz",500,2,0);CheckoutStore.finish(db,true,10L);
        try{CheckoutStore.finish(db,true,11L);fail("Should reject an empty list");}catch(IllegalStateException expected){}
        assertEquals(2,PantryStore.quantity(db,"00000001"));assertEquals(1,scalar("SELECT COUNT(*) FROM purchases"));
    }
    @Test public void overflowKeepsEntireListAndPantry(){
        cart("00000001","Arroz",500,2,1);cart("00000002","Feijão",800,3,0);PantryStore.save(db,"00000001","Arroz",1);PantryStore.save(db,"00000002","Feijão",9998);
        try{CheckoutStore.finish(db,true,10L);fail("Should reject overflow");}catch(IllegalArgumentException expected){}
        assertEquals(1,PantryStore.quantity(db,"00000001"));assertEquals(9998,PantryStore.quantity(db,"00000002"));assertEquals(2,scalar("SELECT COUNT(*) FROM cart"));assertEquals(0,scalar("SELECT COUNT(*) FROM purchases"));assertEquals(0,scalar("SELECT COUNT(*) FROM purchase_items"));
    }
    @Test public void storageFailureRollsBackHistoryStockAndList(){
        cart("00000001","Arroz",500,2,1);cart("00000002","Feijão",800,3,0);PantryStore.save(db,"00000001","Arroz",4);
        db.execSQL("CREATE TRIGGER fail_second BEFORE INSERT ON purchase_items WHEN NEW.ean='00000002' BEGIN SELECT RAISE(ABORT,'simulated storage failure'); END");
        try{CheckoutStore.finish(db,true,10L);fail("Should roll back");}catch(android.database.SQLException expected){}
        assertEquals(4,PantryStore.quantity(db,"00000001"));assertEquals(0,PantryStore.quantity(db,"00000002"));assertEquals(2,scalar("SELECT COUNT(*) FROM cart"));assertEquals(0,scalar("SELECT COUNT(*) FROM purchases"));assertEquals(0,scalar("SELECT COUNT(*) FROM purchase_items"));
    }
    @Test public void historySurvivesDatabaseReopen(){
        cart("00000001","Arroz",500,2,0);CheckoutStore.finish(db,true,10L);helper.close();helper=new ShoppingDatabase(context);db=helper.getWritableDatabase();
        assertEquals(1,scalar("SELECT COUNT(*) FROM purchases"));assertEquals(1000,scalar("SELECT total_cents FROM purchases"));assertEquals(2,PantryStore.quantity(db,"00000001"));
    }
    @Test public void upgradesVersionsOneTwoAndThreeWithoutLosingData(){
        for(int version=1;version<=3;version++){
            helper.close();context.deleteDatabase("compras.db");final int oldVersion=version;
            SQLiteOpenHelper old=new SQLiteOpenHelper(context,"compras.db",null,oldVersion){
                public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE products(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL)");d.execSQL("CREATE TABLE cart(ean TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL,qty INTEGER NOT NULL,checked INTEGER NOT NULL DEFAULT 0"+(oldVersion>=2?",manual_price INTEGER NOT NULL DEFAULT 0":"")+")");if(oldVersion>=3)d.execSQL(PantryStore.CREATE);}
                public void onUpgrade(SQLiteDatabase d,int a,int b){}
            };
            SQLiteDatabase previous=old.getWritableDatabase();previous.execSQL("INSERT INTO cart(ean,name,cents,qty) VALUES('00000001','Arroz',500,2)");if(oldVersion>=2)previous.execSQL("UPDATE cart SET manual_price=1");if(oldVersion>=3)PantryStore.save(previous,"00000001","Arroz",4);old.close();
            helper=new ShoppingDatabase(context);db=helper.getWritableDatabase();assertEquals(1000,scalar("SELECT cents*qty FROM cart"));assertEquals(oldVersion>=2?1:0,scalar("SELECT manual_price FROM cart"));assertEquals(oldVersion>=3?4:0,PantryStore.quantity(db,"00000001"));CheckoutStore.finish(db,true,10L);assertEquals(oldVersion>=3?6:2,PantryStore.quantity(db,"00000001"));
        }
    }
}
