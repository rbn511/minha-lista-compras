package br.com.listacompras;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.StringReader;
import java.util.*;
public class CsvReaderTest {
    @Test public void quotedFieldsPricesAndFirstDuplicate() throws Exception {
        List<String> products=new ArrayList<>();
        int count=CsvReader.read(new StringReader("\uFEFF\"EAN\";\"Descricao\";\"Preco\"\r\n\"0123456789012\";\"Nome; com \"\"aspas\"\"\";\"19,900\"\r\n0123456789012;Outro;30,000\n12345678;Segundo;1,235"),(e,n,c)->products.add(e+"|"+n+"|"+c));
        assertEquals(2,count);assertEquals("0123456789012|Nome; com \"aspas\"|1990",products.get(0));assertEquals("12345678|Segundo|124",products.get(1));
    }
    @Test(expected=java.io.IOException.class) public void rejectsMissingColumns() throws Exception {CsvReader.read(new StringReader("Nome;Valor\nA;10"),(e,n,c)->{});}
    @Test(expected=java.io.IOException.class) public void rejectsInvalidPrice() throws Exception {CsvReader.read(new StringReader("EAN;Descricao;Preco\n12345678;Produto;erro"),(e,n,c)->{});}
    @Test(expected=java.io.IOException.class) public void rejectsTruncatedQuote() throws Exception {CsvReader.read(new StringReader("EAN;Descricao;Preco\n12345678;\"Produto;10"),(e,n,c)->{});}
}
