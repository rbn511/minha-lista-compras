package br.com.listacompras;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class WebAppMigrationTest {
 @Test public void migrationPreservesCartPantryAndHistory()throws Exception{
  SQLiteDatabase db=SQLiteDatabase.create(null);
  db.execSQL("CREATE TABLE products(ean TEXT PRIMARY KEY,name TEXT,cents INTEGER)");db.execSQL("CREATE TABLE cart(ean TEXT PRIMARY KEY,name TEXT,cents INTEGER,qty INTEGER,checked INTEGER)");db.execSQL(PantryStore.CREATE);CheckoutStore.createTables(db);
  db.execSQL("INSERT INTO products VALUES('0123456789012','Leite',799)");db.execSQL("INSERT INTO cart VALUES('0123456789012','Leite',799,2,1)");PantryStore.save(db,"0123456789012","Leite",3);
  CheckoutStore.finish(db,true,1000);db.execSQL("INSERT INTO cart VALUES('0123456789012','Leite',699,1,0)");JSONObject result=LegacyMigration.export(db,null),s=result.getJSONObject("state");assertEquals(5,s.getJSONObject("pantry").getJSONObject("0123456789012").getInt("qty"));assertEquals(699,s.getJSONObject("cart").getJSONObject("0123456789012").getInt("cents"));assertEquals(1598,s.getJSONArray("history").getJSONObject(0).getInt("total"));assertEquals(799,result.getJSONObject("catalog").getJSONObject("0123456789012").getInt("cents"));db.close();
 }
 @Test public void bridgeTrustsOnlyPackagedHttpsAssets(){assertTrue(WebAppActivity.isTrusted(Uri.parse("https://appassets.androidplatform.net/assets/index.html")));assertFalse(WebAppActivity.isTrusted(Uri.parse("https://appassets.androidplatform.net.evil.example/assets/index.html")));assertFalse(WebAppActivity.isTrusted(Uri.parse("http://appassets.androidplatform.net/assets/index.html")));assertFalse(WebAppActivity.isTrusted(Uri.parse("https://appassets.androidplatform.net:443/assets/index.html")));assertFalse(WebAppActivity.isTrusted(Uri.parse("https://example.com/assets/index.html")));}
}
