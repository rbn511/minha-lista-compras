package br.com.listacompras;
import org.junit.Test;
import static org.junit.Assert.*;
public class PantryQuantityTest {
    @Test public void registersCountAndTracksConsumptionAndRestocking(){int stock=PantryQuantity.parse(" 3 ");stock=PantryQuantity.changed(stock,-1);assertEquals(2,stock);stock=PantryQuantity.changed(stock,1);assertEquals(3,stock);assertEquals("Você já tem 3 unidades na despensa",PantryQuantity.notice(stock));}
    @Test public void consumptionNeverMakesStockNegative(){assertEquals(0,PantryQuantity.changed(0,-1));assertEquals(0,PantryQuantity.changed(1,-1));assertEquals("Na despensa: nenhuma unidade",PantryQuantity.notice(0));}
    @Test public void handlesOneUnitAndMaximum(){assertEquals("Você já tem 1 unidade na despensa",PantryQuantity.notice(1));assertEquals(9999,PantryQuantity.parse("9999"));}
    @Test(expected=IllegalArgumentException.class) public void rejectsFraction(){PantryQuantity.parse("1,5");}
    @Test(expected=IllegalArgumentException.class) public void rejectsNegative(){PantryQuantity.parse("-1");}
    @Test(expected=IllegalArgumentException.class) public void rejectsEmpty(){PantryQuantity.parse("");}
    @Test(expected=IllegalArgumentException.class) public void rejectsOversizedCount(){PantryQuantity.parse("10000");}
    @Test(expected=IllegalArgumentException.class) public void rejectsOverflow(){PantryQuantity.changed(9999,1);}
}
