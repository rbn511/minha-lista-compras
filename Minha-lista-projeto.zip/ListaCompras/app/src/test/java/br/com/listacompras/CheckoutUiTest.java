package br.com.listacompras;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;
import org.robolectric.shadows.ShadowAlertDialog;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class CheckoutUiTest {
    private ShoppingDatabase helper;private SQLiteDatabase db;private ActivityController<MainActivity> controller;private MainActivity activity;
    @Before public void setup(){RuntimeEnvironment.getApplication().deleteDatabase("compras.db");helper=new ShoppingDatabase(RuntimeEnvironment.getApplication());db=helper.getWritableDatabase();db.execSQL("INSERT INTO cart(ean,name,cents,qty,checked) VALUES('00000001','Arroz',500,2,0)");PantryStore.save(db,"00000001","Arroz",3);controller=Robolectric.buildActivity(MainActivity.class).setup();activity=controller.get();}
    @After public void cleanup(){controller.pause().stop().destroy();helper.close();RuntimeEnvironment.getApplication().deleteDatabase("compras.db");}
    private Button find(View root,String text){if(root instanceof Button&&text.contentEquals(((Button)root).getText()))return (Button)root;if(root instanceof ViewGroup){ViewGroup group=(ViewGroup)root;for(int i=0;i<group.getChildCount();i++){Button result=find(group.getChildAt(i),text);if(result!=null)return result;}}return null;}
    private void click(String text){Button button=find(activity.getWindow().getDecorView(),text);assertNotNull(text,button);assertEquals(View.VISIBLE,button.getVisibility());assertTrue(button.isEnabled());button.performClick();}
    private long count(String table){try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM "+table,null)){c.moveToFirst();return c.getLong(0);}}
    @Test public void cancelKeepsListAndStock(){click("Finalizar compra");AlertDialog dialog=ShadowAlertDialog.getLatestAlertDialog();assertTrue(dialog.isShowing());dialog.getButton(AlertDialog.BUTTON_NEUTRAL).performClick();assertEquals(1,count("cart"));assertEquals(3,PantryStore.quantity(db,"00000001"));assertEquals(0,count("purchases"));}
    @Test public void confirmAddsUnmarkedItemsAndShowsHistory(){click("Finalizar compra");AlertDialog dialog=ShadowAlertDialog.getLatestAlertDialog();dialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();assertEquals(5,PantryStore.quantity(db,"00000001"));assertEquals(0,count("cart"));assertEquals(1,count("purchases"));ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_POSITIVE).performClick();click("Histórico");click("Ver produtos");assertTrue(ShadowAlertDialog.getLatestAlertDialog().isShowing());}
    @Test public void declineFinalizesWithoutChangingStock(){click("Finalizar compra");ShadowAlertDialog.getLatestAlertDialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();assertEquals(3,PantryStore.quantity(db,"00000001"));assertEquals(0,count("cart"));assertEquals(1,count("purchases"));}
    @Test public void navigationKeepsImportsInMoreAndPantrySeparate(){assertNull(find(activity.getWindow().getDecorView(),"Importar preços (.csv)"));click("Mais");assertNotNull(find(activity.getWindow().getDecorView(),"Importar preços (.csv)"));click("Despensa");click("Entrou 1");assertEquals(4,PantryStore.quantity(db,"00000001"));click("Compras");assertEquals(1,count("cart"));assertNotNull(find(activity.getWindow().getDecorView(),"Alterar preço"));}
}
