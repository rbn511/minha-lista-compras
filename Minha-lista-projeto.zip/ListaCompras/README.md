# Minha lista

Projeto Android para importar preços em CSV, ler códigos de barras pela câmera e guardar uma lista de compras no aparelho. Android 7 ou superior.

## Estado

Código preparado para compilação no GitHub Actions. APK ainda não compilado nem testado em celular. Os testes de importação serão executados na compilação em nuvem.

## Gerar em nuvem

Envie o conteúdo desta pasta para a raiz de um repositório no GitHub, incluindo `.github/workflows/apk.yml`. Em Actions, execute “Gerar APK”. Ao terminar, baixe o artefato “Minha-lista-APK”, extraia o ZIP e transfira `app-debug.apk` para o Android. Este APK é uma versão de testes. Uma versão definitiva precisa de assinatura persistente para permitir atualizações sem reinstalar.

## Usar

1. Transfira seu CSV para o celular.
2. Toque em “Importar preços (.csv)” e escolha o arquivo.
3. Toque em “Escanear produto” e permita o uso da câmera.
4. Confirme o produto, ajuste quantidades e marque os itens comprados.

O CSV deve estar em UTF-8, separado por ponto e vírgula e conter `EAN`, `Descricao` e `Preco`. Preços brasileiros como `19,900` são aceitos e arredondados para centavos. Códigos são preservados como texto, incluindo zeros iniciais. Usa o primeiro registro de cada EAN, sem seleção de loja. A importação substitui a base de preços e atualiza os preços dos itens encontrados na lista; itens ausentes mantêm o preço anterior. Uma importação inválida mantém a base anterior. A busca mostra até 50 resultados.

O arquivo de preços do usuário não está incluído no projeto. Scanner baseado em [ZXing Android Embedded](https://github.com/journeyapps/zxing-android-embedded), com leitura local.
