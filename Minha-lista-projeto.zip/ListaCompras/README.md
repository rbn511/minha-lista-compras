# Minha Casa 2.0

Aplicativo Android e versão web para compras, despensa e histórico. Scanner em pé, cards compactos e menu de ações ao tocar no produto.

## Recursos

- Importação local de CSV, preços em centavos e total por quantidade.
- Finalização de todos os itens, com opção de atualizar a despensa.
- Categorias, estoque mínimo, reposição e avisos de validade até 7 dias antes ou após vencimento.
- Gastos mensais e preços anteriores por produto.
- Conta por e-mail/senha, casa compartilhada e convites válidos por 24 horas e usados uma vez, até 10 participantes.
- Firebase Authentication e Firestore no projeto minha-casa-compras-e-despensa, Spark sem cobrança. CSV e fotos da galeria ficam locais.
- Alterações offline salvas no aparelho e sincronizadas quando a conexão volta. Conflitos ficam pendentes para revisão. Finalizar uma compra compartilhada exige conexão e nenhuma alteração pendente.
- Backup JSON de lista, despensa, histórico, catálogo e fotos locais. Não inclui senhas. Restauração local pede confirmação; saia da casa compartilhada primeiro.
- Fotos opcionais de Open Food Facts, Open Beauty Facts e Open Products Facts ou galeria. Nem todo produto possui imagem no catálogo.

## Atualizações

Compilação no GitHub Actions e assinatura com chave permanente mantida privadamente no computador do proprietário. Não envie a chave ou sua senha ao repositório. Preserve um backup privado.

A versão 1.5 usava uma assinatura temporária diferente por compilação. A versão 2.0 exige uma reinstalação inicial; desinstalar apaga os dados locais anteriores. As próximas versões assinadas com esta mesma chave podem ser instaladas como atualização. Dados sincronizados voltam ao entrar na conta; fotos e CSV precisam de backup local.

## Desenvolvimento e testes

Java 17, Gradle 8.11.1, AGP 8.9, compileSdk 35, minSdk 24. Interface empacotada em assets, servida por WebViewAssetLoader em origem HTTPS local. Links externos abrem no navegador. Câmera, fotos e documentos usam seletores Android.

Execute gradle testDebugUnitTest assembleDebug. Testes de preços, persistência, finalização, migração e origem confiável. A pasta irmã MinhaCasaWeb contém o modelo, a interface, as regras e testes Firebase em um projeto de demonstração do emulador. Câmera e galeria precisam de conferência no aparelho.
