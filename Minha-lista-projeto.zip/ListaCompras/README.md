# Minha lista

Projeto Android para importar preços em CSV, ler códigos de barras pela câmera e guardar uma lista de compras no aparelho. Android 7 ou superior.

## Estado

Versão 1.5 com itens compactos e menu de ações ao tocar no produto. Compilação e testes automatizados pelo GitHub Actions, incluindo alteração de preço/quantidade pelo menu, recálculo do total, confirmação de remoção, acesso ao seletor de fotos, finalização e os registros da despensa e histórico. Leitura de câmera e escolha de fotos precisam ser verificadas no aparelho.

## Gerar em nuvem

Envie o conteúdo desta pasta para a raiz de um repositório no GitHub, incluindo `.github/workflows/apk.yml`. Em Actions, execute “Gerar APK”. Ao terminar, baixe o artefato “Minha-lista-APK”, extraia o ZIP e transfira `app-debug.apk` para o Android. Este APK é uma versão de testes. Uma versão definitiva precisa de assinatura persistente para permitir atualizações sem reinstalar.

## Usar

1. Transfira seu CSV para o celular.
2. Na aba “Mais”, toque em “Importar preços (.csv)” e escolha o arquivo.
3. Na aba “Compras”, toque em “Escanear” e permita o uso da câmera.
4. Cada item da lista mostra foto (quando disponível), nome, quantidade, preço e estoque em casa. Toque no item para abrir o menu: “Alterar preço”, “Alterar quantidade”, “Adicionar ou trocar foto” e “Remover item”. A caixa de marcação continua disponível para conferir os produtos sem abrir o menu.
5. Para preços ausentes ou diferentes, informe o preço unitário ao adicionar ou use “Alterar preço” no menu do item. Em “Alterar quantidade”, digite a quantidade ou use os botões +/− e toque em “Salvar” para recalcular o total. Os valores informados manualmente são mantidos ao importar outro CSV. Remover um item exige confirmação e não altera a despensa.
6. Em “Minha despensa”, escaneie ou busque um produto e informe a quantidade total em casa. Para produto fora do CSV, digite o código na busca ou escaneie e informe o nome.
7. Use “Consumir 1”, “Entrou 1” e “Editar quantidade” para manter o estoque. Quantidades inteiras entre 0 e 9999; zero indica que acabou. A mesma embalagem é reconhecida pelo código de barras, preservando zeros iniciais.
8. Ao adicionar à lista de compras, a confirmação mostra a quantidade na despensa. A informação também aparece nos resultados da busca e em cada item da lista.

A lista de compras e a despensa têm quantidades independentes. Adicionar à lista não registra uma entrada automática. Em “Finalizar compra”, a lista inteira é considerada comprada (incluindo itens não marcados). Escolha “Sim, atualizar” para somar as quantidades ao estoque existente ou “Não, só finalizar” para manter a despensa. “Cancelar” mantém a lista e o estoque. A finalização grava os produtos, preços, quantidades e total no Histórico e esvazia a lista. Toda a operação ocorre em uma transação: um erro mantém os dados anteriores e não registra uma compra parcial. O estoque não pode ultrapassar 9999 unidades por produto.

O menu inferior possui “Compras”, “Despensa”, “Histórico” e “Mais”. O Histórico mostra as 50 compras mais recentes e os produtos de cada uma. Limpar a lista ou importar preços não apaga a despensa nem o histórico. Dados armazenados somente no aparelho.

Fotos disponíveis no Open Food Facts ou Open Beauty Facts são buscadas por código de barras. “Adicionar foto” permite escolher uma imagem do celular, armazenada somente no aplicativo.

O CSV deve estar em UTF-8, separado por ponto e vírgula e conter `EAN`, `Descricao` e `Preco`. Preços brasileiros como `19,900` são aceitos e arredondados para centavos. Códigos são preservados como texto, incluindo zeros iniciais. Usa o primeiro registro de cada EAN, sem seleção de loja. A importação substitui a base de preços e atualiza os preços dos itens encontrados na lista; itens ausentes mantêm o preço anterior. Uma importação inválida mantém a base anterior. A busca mostra até 50 resultados.

O arquivo de preços do usuário não está incluído no projeto. Scanner baseado em [ZXing Android Embedded](https://github.com/journeyapps/zxing-android-embedded), com leitura local.
