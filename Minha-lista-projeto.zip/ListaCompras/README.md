# Minha lista

Projeto Android para importar preços em CSV, ler códigos de barras pela câmera e guardar uma lista de compras no aparelho. Android 7 ou superior.

## Estado

Versão 1.3 com cadastro da despensa. Compilação e testes automatizados pelo GitHub Actions. Leitura de câmera e escolha de fotos precisam ser verificadas no aparelho.

## Gerar em nuvem

Envie o conteúdo desta pasta para a raiz de um repositório no GitHub, incluindo `.github/workflows/apk.yml`. Em Actions, execute “Gerar APK”. Ao terminar, baixe o artefato “Minha-lista-APK”, extraia o ZIP e transfira `app-debug.apk` para o Android. Este APK é uma versão de testes. Uma versão definitiva precisa de assinatura persistente para permitir atualizações sem reinstalar.

## Usar

1. Transfira seu CSV para o celular.
2. Toque em “Importar preços (.csv)” e escolha o arquivo.
3. Toque em “Escanear produto” e permita o uso da câmera.
4. Confirme o produto, ajuste quantidades e marque os itens comprados.
5. Para preços ausentes ou diferentes, informe o preço unitário ao adicionar ou toque em “Alterar preço”. Os valores informados manualmente são mantidos ao importar outro CSV.
6. Em “Minha despensa”, escaneie ou busque um produto e informe a quantidade total em casa. Para produto fora do CSV, digite o código na busca ou escaneie e informe o nome.
7. Use “Consumir 1”, “Entrou 1” e “Editar quantidade” para manter o estoque. Quantidades inteiras entre 0 e 9999; zero indica que acabou. A mesma embalagem é reconhecida pelo código de barras, preservando zeros iniciais.
8. Ao adicionar à lista de compras, a confirmação mostra a quantidade na despensa. A informação também aparece nos resultados da busca e em cada item da lista.

A lista de compras e a despensa têm quantidades independentes. Comprar/adicionar à lista não registra uma entrada automática; registre em “Minha despensa” quando guardar os produtos em casa. Limpar a lista ou importar preços não apaga o estoque.

Fotos disponíveis no Open Food Facts ou Open Beauty Facts são buscadas por código de barras. “Adicionar foto” permite escolher uma imagem do celular, armazenada somente no aplicativo.

O CSV deve estar em UTF-8, separado por ponto e vírgula e conter `EAN`, `Descricao` e `Preco`. Preços brasileiros como `19,900` são aceitos e arredondados para centavos. Códigos são preservados como texto, incluindo zeros iniciais. Usa o primeiro registro de cada EAN, sem seleção de loja. A importação substitui a base de preços e atualiza os preços dos itens encontrados na lista; itens ausentes mantêm o preço anterior. Uma importação inválida mantém a base anterior. A busca mostra até 50 resultados.

O arquivo de preços do usuário não está incluído no projeto. Scanner baseado em [ZXing Android Embedded](https://github.com/journeyapps/zxing-android-embedded), com leitura local.
